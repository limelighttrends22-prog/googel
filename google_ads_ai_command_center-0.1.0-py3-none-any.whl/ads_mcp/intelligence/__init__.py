"""Explainable Google Ads intelligence. No advertising mutation methods."""
